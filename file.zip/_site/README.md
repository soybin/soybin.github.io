# my blog
## *here i simplify and explain some useful technical concepts in the hoping for being of good use to somebody.*  
  
**_big thanks to [Tom Preston-Werner](https://github.com/mojombo) for providing this elegant template, and also for cofounding github._**
